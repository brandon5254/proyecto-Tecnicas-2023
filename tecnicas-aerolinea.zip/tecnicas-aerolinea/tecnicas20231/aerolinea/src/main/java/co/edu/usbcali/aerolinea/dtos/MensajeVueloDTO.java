package co.edu.usbcali.aerolinea.dtos;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MensajeVueloDTO {
    private String mensaje;
}
